﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;
using System.IO;
using System.Diagnostics;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            string type = args[0];
            string file = args[1];

            if (!File.Exists(file))
            {
                Console.WriteLine("File Not Exists.!!");
                Console.ReadKey();
                return;
            }

            if (type.ToLower().Equals("–v") || type.ToLower().Equals("--v") || type.ToLower().Equals("/v") || type.ToLower().Equals("--version"))
            {
                FileVersionInfo myFileVersionInfo = FileVersionInfo.GetVersionInfo(file);               
                Console.WriteLine("File version is: " + myFileVersionInfo.FileVersion);                
            }
            else if (type.ToLower().Equals("–s") || type.ToLower().Equals("–s") || type.ToLower().Equals("–s") || type.ToLower().Equals("--size"))
            {
                FileInfo myFileInfo = new FileInfo(file);
                Console.WriteLine("File Size in Bytes: " + myFileInfo.Length);
            }
            Console.ReadKey();
        }
    }
}
